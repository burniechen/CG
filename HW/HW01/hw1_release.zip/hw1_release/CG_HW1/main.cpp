#include <GLFW/glfw3.h>
#include <GL/freeglut.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <iostream>
#include <stb_image.h>

#define M_PI 3.14159265358979323846

using namespace std;
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_button_callback(GLFWwindow* window, int button, int action, int mods);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);

static void error_callback(int error, const char* description);
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);


const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

//------------- TO DO ------------- 
// Declaration: ex. mouse events variables, camera positions ...



void mySphere(double r, int slice, int stack) {
    //------------- TO DO ------------- 
    // Draw your sphere





}

void myCube() {
    //------------- TO DO ------------- 
    // Draw your cube


}

int main()
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit())
        exit(EXIT_FAILURE);
    window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "CG_HW1_TA", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSetKeyCallback(window, key_callback);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetMouseButtonCallback(window, mouse_button_callback);
    glfwSetScrollCallback(window, scroll_callback);

    unsigned int texture1, texture2, texture3;

    //------------- TO DO ------------- 
    // Generate textures








    //------------- TO DO ------------- 
    // Enable lighting








    while (!glfwWindowShouldClose(window))
    {

        //------------- TO DO ------------- 
        //Declare your variables




        int width, height;
        glfwGetFramebufferSize(window, &width, &height);


        //------------- TO DO ------------- 
        // gluLookAt(eye, center, up)



        //ModelView Matrix
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        //Projection Matrix
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(45.0f, width / (GLfloat)height, 0.1, 1000);

        //Viewport Matrix
        glViewport(0, 0, width, height);


        //------------- TO DO ------------- 
        // Enable GL capabilities



        // clear
        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        glClearDepth(1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        //------------- TO DO ------------- 
        // Rotate, Draw and Switch objects




        glfwSwapBuffers(window);
        glfwPollEvents();


    }

    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);

    return 0;
}

static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);

    //------------- TO DO ------------- 
    // Define your keyboard event

}


void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
    //------------- TO DO ------------- 
    // Define your mouse event

}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    //------------- TO DO ------------- 
    // (optional) Define your scroll event

}